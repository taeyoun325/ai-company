/*
  UI-only shell for AI COMPANY.
  Claude should connect the existing orchestration logic through the adapter
  functions documented in INTEGRATION.md. Do not replace these views with mock AI logic.
*/
const state={mode:'auto',jobs:0,saved:0,projects:[
  {name:'계산기 모듈 + 사용법 문서',desc:'사칙연산 모듈과 사용자 문서 제작',tags:['기획','개발','QA']},
  {name:'AI COMPANY MVP',desc:'멀티 에이전트 실행 대시보드',tags:['제품','UI','백엔드']},
  {name:'브랜드 소개 페이지',desc:'신규 서비스의 랜딩 페이지 제작',tags:['디자인','카피']}
]};
const employees=[
  {name:'한지수',role:'전략가',icon:'🧭',model:'claude-opus-5',desc:'요구사항을 인수기준과 작업 그래프로 바꿉니다. 파일은 쓰지 않습니다.',perms:'쓰기 없음 · 읽기 src/ tests/ docs/ design/',status:'대기'},
  {name:'박도현',role:'개발자',icon:'🛠️',model:'claude-opus-5',desc:'코드를 씁니다. src/에만 쓸 수 있고 tests/는 읽기만 합니다.',perms:'쓰기 src/ · 읽기 src/ docs/ design/',status:'대기'},
  {name:'최유나',role:'분석가',icon:'🔎',model:'gemini-2.5-pro',desc:'다른 모델과 별도로 교차검증합니다. tests/에만 쓰고 코드는 읽기만 합니다.',perms:'쓰기 tests/ · 읽기 src/ tests/ docs/ design/',status:'대기'},
  {name:'이서준',role:'작가',icon:'✍️',model:'gpt-5',desc:'문서·카피를 씁니다. docs/와 읽기 영역만 사용합니다.',perms:'쓰기 docs/ · 읽기 src/ docs/ design/',status:'대기'},
  {name:'정하린',role:'디자이너',icon:'🎨',model:'gemini-2.5-pro',desc:'화면과 비주얼을 명세합니다. design/에만 씁니다.',perms:'쓰기 design/ · 읽기 src/ docs/ design/',status:'대기'}
];
const $=s=>document.querySelector(s); const $$=s=>[...document.querySelectorAll(s)];
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function renderEmployees(){
  $('#employeeGrid').innerHTML=employees.map(e=>`<article class="employee-card" data-name="${e.name}"><div class="emp-top"><div class="emp-icon">${e.icon}</div><div><div class="emp-name">${e.name} <span class="mock">UI SHELL</span></div><div class="emp-role">${e.role}</div></div></div><p class="emp-desc">${e.desc}</p><div class="emp-stats"><div class="stat"><small>모델</small><b>${e.model}</b></div><div class="stat"><small>호출</small><b data-calls="${e.name}">0</b></div><div class="stat"><small>비용</small><b data-cost="${e.name}">$0</b></div></div><div class="emp-perms">${e.perms}</div><div class="emp-status"><span class="mini-dot"></span><span data-status="${e.name}">${e.status}</span></div></article>`).join('');
}
function renderProjects(){
  $('#projectGrid').innerHTML=state.projects.map((p,i)=>`<article class="project-card"><div class="eyebrow">PROJECT ${String(i+1).padStart(2,'0')}</div><h3>${p.name}</h3><p>${p.desc}</p><div class="project-meta">${p.tags.map(t=>`<span class="tag">${t}</span>`).join('')}</div></article>`).join('')
}
function addActivity(title,body,icon='⚡'){
  const row=document.createElement('div');row.className='activity-item';row.innerHTML=`<div class="activity-icon">${icon}</div><div><b>${title}</b><p>${body}</p></div><span class="activity-time">방금 전</span>`;$('#activityList').prepend(row);const rows=$$('#activityList .activity-item');if(rows.length>6)rows.at(-1).remove()
}
function simulateUiOnly(){
  // Visual state only. Replace with real orchestration bridge.
  const btn=$('#runBtn');btn.disabled=true;$('#runState').textContent='RUNNING';toast('작업 실행 UI를 시작했습니다. 기존 오케스트레이션 함수에 연결하세요.');
  employees.forEach((e,i)=>setTimeout(()=>{const card=document.querySelector(`.employee-card[data-name="${e.name}"]`);if(card){card.classList.add('working');card.querySelector(`[data-status="${e.name}"]`).textContent='작업 중';}},i*280));
  setTimeout(()=>{employees.forEach(e=>{const el=document.querySelector(`[data-status="${e.name}"]`);if(el)el.textContent='대기';const card=document.querySelector(`.employee-card[data-name="${e.name}"]`);if(card)card.classList.remove('working')});state.jobs++;state.saved+=12;$('#metricJobs').textContent=state.jobs;$('#metricSaved').textContent=state.saved;$('#runState').textContent='READY';btn.disabled=false;addActivity('오케스트레이션 UI 요청 완료','실제 PM → DEV → QA → WRITER → UI 파이프라인에 연결 대기','✓')},1850)
}
function wireNav(){
  $$('.nav-item').forEach(btn=>btn.addEventListener('click',()=>{const v=btn.dataset.view;$$('.nav-item').forEach(x=>x.classList.toggle('active',x===btn));$$('.view').forEach(x=>x.classList.remove('active-view'));$('#view-'+v).classList.add('active-view');history.replaceState(null,'','#'+v)}));
}
$$('.mode-btn').forEach(btn=>btn.addEventListener('click',()=>{$$('.mode-btn').forEach(x=>x.classList.remove('active'));btn.classList.add('active');state.mode=btn.dataset.mode}));
$('#runBtn').addEventListener('click',()=>{const text=$('#commandInput').value.trim();if(!text){toast('먼저 작업을 입력하세요.');$('#commandInput').focus();return}if(window.AICompanyAPI?.runTask){window.AICompanyAPI.runTask({prompt:text,mode:state.mode})}else{simulateUiOnly();addActivity('새 요청 등록',text.slice(0,85), '＋')}});
$('#refreshBtn').addEventListener('click',()=>window.AICompanyAPI?.refreshStatus?window.AICompanyAPI.refreshStatus():toast('현재 UI 상태를 새로고침했습니다.'));
$('#newProjectBtn').addEventListener('click',()=>{const name=prompt('프로젝트 이름');if(!name)return;state.projects.unshift({name,desc:'새 프로젝트 · 실제 프로젝트 기능에 연결 필요',tags:['NEW']});renderProjects();toast('프로젝트 카드가 추가되었습니다. 실제 저장 로직에 연결하세요.')});
$('#themeBtn').addEventListener('click',()=>document.body.classList.toggle('dark'));
renderEmployees();renderProjects();addActivity('시스템 준비 완료','AI 직원 5명이 대기 상태입니다.','✓');$('#metricJobs').textContent='0';$('#metricSaved').textContent='0';wireNav();
