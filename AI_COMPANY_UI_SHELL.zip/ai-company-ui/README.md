# AI COMPANY — Premium UI Shell

기존 AI 오케스트레이션 기능을 그대로 유지하면서, UI만 고급 제품 수준으로 교체할 수 있도록 만든 프론트엔드 셸입니다.

## 파일
- `index.html` — 화면 구조
- `styles.css` — 반응형 디자인 시스템
- `app.js` — UI 상태 / 이벤트 연결 지점
- `INTEGRATION.md` — Claude 연결 가이드 + 복붙용 프롬프트

## 현재 화면
- 사무실 대시보드
- COMMAND CENTER
- PM / DEV / QA / WRITER / UI 직원 카드
- 실행 기록
- 프로젝트
- 요금제
- 설정
- 다크 모드
- 모바일 반응형

실제 AI 동작은 포함하지 않으며, 기존 오케스트레이션 기능을 연결하는 것을 전제로 합니다.
